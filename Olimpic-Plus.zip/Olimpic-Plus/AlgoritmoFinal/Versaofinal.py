

import json 
import os
import time
from ctypes import *
from menu import * 

def main():
	comando = 0
	while 1:
		print("Escolha a modalidade para inserir dados:")
		print(" (1) Corrida \n (2) Salto em distância")
		print(" (3) Tiro esportivo \n (4) Sair")
		try:
			comando = float(input("Digite o comando: "))
			clear()
		except:
			print("Você não inseriu um comando válido")
			time.sleep(1)
			clear()
		if comando == 1:
			
			comandos('corrida','tempo','tempo em segundos')
		
		if comando == 2:
			
			comandos('salto em distancia','metros','distancia em metros')
		
		if comando == 3:
			
			comandos('tiro esportivo','pontuacao','pontuacao')
			
		if comando == 4:
			break

main()
