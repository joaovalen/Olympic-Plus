import json

def abrirJson(modalidade):
	agenda = []
	try:
		arquivo = open (modalidade + '.json','r')
		try:
			agenda = json.load(arquivo)
		except:
			print("arquivo estava vazio")
			agenda = []
		arquivo.close()
	except:
		print("Erro ao abrir /ler JSON")
	return agenda
