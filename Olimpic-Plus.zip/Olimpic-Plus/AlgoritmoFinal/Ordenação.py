def bubbleSort(agenda,chave):
    for passnum in range(len(agenda)-1,0,-1):
        for i in range(passnum):
            if agenda[i][chave]>agenda[i+1][chave]:
                temp = agenda[i]
                agenda[i] = agenda[i+1]
                agenda[i+1] = temp

def bubbleSortReverse(agenda,chave):
	for passnum in range(len(agenda)-1,0,-1):
		for i in range(passnum):
			if agenda[i][chave]<agenda[i+1][chave]:
				temp = agenda[i]
				agenda[i] = agenda[i+1]
				agenda[i+1] = temp	
