import json 
import os
import time
from ctypes import *
from Ordenação import *
from AbrirJson import *


clear=lambda:os.system('cls')
 
STD_OUTPUT_HANDLE = -11
 
class COORD(Structure):
    pass
 
COORD._fields_ = [("X", c_short), ("Y", c_short)]
 
def gotoxyz(r, c, s):
    h = windll.kernel32.GetStdHandle(STD_OUTPUT_HANDLE)
    windll.kernel32.SetConsoleCursorPosition(h, COORD(c, r))
 
    c = s.encode("windows-1252")
    windll.kernel32.WriteConsoleA(h, c_char_p(c), len(c), None, None)


#Quando o valor é invalido(letra) ele fecha o programa		
def comandos(modalidade,medida,chave):	
	clear=lambda:os.system('cls')
	agenda = abrirJson(modalidade)
	while 1:
		print("O que você deseja fazer? \n \n (1) inserir dados de participante")
		print(" (2) Ver estatísticas \n (3) mostrar todos os dados salvos ")
		print(" (4) deletar contato \n (5) voltar\n ")
		comando2 = int(input("Digite o comando: "))
			
		if comando2 == 1:	
			print('\n')
			inserirparticipante(agenda,modalidade,medida,chave)
			clear()
			gotoxyz(11, 23, "Participante inserido com sucesso")
			salvarAgenda(agenda,modalidade,chave)
			time.sleep(1)
			clear()						
			
		if comando2 == 2:
			print('\n')
			media(agenda,medida,modalidade,chave)
			time.sleep(3)
			clear()
			
			podio(agenda,medida,modalidade)
			time.sleep(5)
			clear()
			
			totalpart(agenda,medida,modalidade)
			a = input('\nDigite "ENTER" para voltar:')
			if a == '':
				clear()
			
			
		if comando2 == 3:
			print('\n')
			agenda = abrirJson(modalidade)
			mostraagenda(agenda,medida,modalidade)
			a = input('\nDigite "ENTER" para voltar:')
			if a == '':
				clear()
		
		if comando2 == 4:
			print('\n')
			deletar(agenda,medida,modalidade,chave)
			clear()
			gotoxyz(11, 25, "Participante deletado com sucesso")
			time.sleep(1)
			clear()
			
		if comando2 == 5:
			clear()
			break

# 1 Quando o valor é invalido(letra) ele fecha o programa
def inserirparticipante(agenda,modalidade,medida,chave):
	nome = input("Digite o nome do participante: ")
	valor = float(input("Digite o(a) " +medida+ " do participante: "))
	pais = input("Digite o país que o participante está representando: ")
	try:
		agenda.append({'nome': nome, chave: valor, 'pais': pais})									
	except:
		print("Erro na execução")	

	

#Estatísticas
def media(agenda,medida,modalidade,chave):
	soma = 0
	x = 0
	resultado = 0
	if modalidade == 'corrida':	
		for a in agenda:
			x += 1
			soma = soma + a[chave]
			resultado = soma / x
		R = resultado
		clear()
		gotoxyz(11,17,"A media de tempo da prova foi de: ")
		gotoxyz(11,51, str(R))
		gotoxyz(11,50," ")
		gotoxyz(11,56," segundos        ")
		
	
	elif modalidade == 'salto em distancia':
		
		for a in agenda:
			x += 1
			soma = soma + a[chave]
			resultado = soma / x
		R = [resultado]
		R = str(R)
		clear()
		gotoxyz(11,17,"A media de distancia da prova foi de: ")
		gotoxyz(11,50,(R))
		gotoxyz(11,50," ")
		gotoxyz(11,56," metros  ")
		
		
	elif modalidade == 'tiro esportivo':
	
		for a in agenda:
			x += 1
			soma = soma + a[chave]
			resultado = soma / x
		R = [resultado]
		R = str(R)
		clear()
		gotoxyz(11,17,"A media de pontos da prova foi de: ")
		gotoxyz(11,50,(R))
		gotoxyz(11,50," ")
		gotoxyz(11,56," pontos  ")
		
#Estatísticas		
def podio(agenda,medida,modalidade):
	
	if (str(medida) == "tempo"):
		gotoxyz(12,30,'PODIO \n')
		
		print("\n			Nome :", agenda[0]['nome'])
		print("			Tempo (s):", agenda[0]['tempo em segundos'])
		print(' 			País :', agenda[0]['pais'])
		print(' ' * 23, '█' * 23)
		
		enome = 15 - len(agenda[1]['nome'])
		etempo = str(agenda[1]['tempo em segundos'])
		etempo = 11 - len(etempo)
		epais = 15 - len(agenda[1]['pais'])
		
		print("Nome :", agenda[1]['nome'], enome * ' ' ,3 * '█', "Primeiro Lugar", 4 * '█')
		print("Tempo (s):", agenda[1]['tempo em segundos'] , etempo * ' ',23 * '█')
		print('País :', agenda[1]['pais'], epais * ' ' ,23 * '█')
		
		print('█' * 47)
		print('█' * 4, 'Segundo Lugar', '█' * 28, "Nome :", agenda[2]['nome'])
		print('█' * 47, "Tempo (s):", agenda[2]['tempo em segundos'])
		print('█' * 47, 'País :', agenda[2]['pais'])
		print('█' * 70)
		print('█' * 50, 'Terceiro Lugar', '█' * 4)
		print('█' * 70)
			
	if (str(medida) == "metros"):
		gotoxyz(12,30,'PODIO \n')
		
		print("\n			Nome :", agenda[0]['nome'])
		print("			Distancia (m):", agenda[0]['distancia em metros'])
		print(' 			País :', agenda[0]['pais'])
		print(' ' * 23, '█' * 23)
			
		enome = 15 - len(agenda[1]['nome'])
		etempo = str(agenda[1]['distancia em metros'])
		etempo = 8 - len(etempo)
		epais = 15 - len(agenda[1]['pais'])
			
		print("Nome :", agenda[1]['nome'], enome * ' ' ,3 * '█', "Primeiro Lugar", 4 * '█')
		print("Distancia(m):", agenda[1]['distancia em metros'] , etempo * ' ',23 * '█')
		print('País :', agenda[1]['pais'], epais * ' ' ,23 * '█')
			
		print('█' * 47)
		print('█' * 4, 'Segundo Lugar', '█' * 28, "Nome :", agenda[2]['nome'])
		print('█' * 47, "Distancia (m):", agenda[2]['distancia em metros'])
		print('█' * 47, 'País :', agenda[2]['pais'])
		print('█' * 70)
		print('█' * 50, 'Terceiro Lugar', '█' * 4)
		print('█' * 70)
			
			
	if (str(medida) == "pontuacao"):
		gotoxyz(12,30,'PODIO \n')
		
		print("\n			Nome :", agenda[0]['nome'])
		print("			Pontuação:", agenda[0]['pontuacao'])
		print(' 			País :', agenda[0]['pais'])
		print(' ' * 23, '█' * 23)
			
		enome = 15 - len(agenda[1]['nome'])
		etempo = str(agenda[1]['pontuacao'])
		etempo = 11 - len(etempo)
		epais = 15 - len(agenda[1]['pais'])
			
		print("Nome :", agenda[1]['nome'], enome * ' ' ,3 * '█', "Primeiro Lugar", 4 * '█')
		print("Pontuação:", agenda[1]['pontuacao'] , etempo * ' ',23 * '█')
		print('País :', agenda[1]['pais'], epais * ' ' ,23 * '█')
			
		print('█' * 47)
		print('█' * 4, 'Segundo Lugar', '█' * 28, "Nome :", agenda[2]['nome'])
		print('█' * 47, "Pontuação:", agenda[2]['pontuacao'])
		print('█' * 47, 'País :', agenda[2]['pais'])
		print('█' * 70)
		print('█' * 50, 'Terceiro Lugar', '█' * 4)
		print('█' * 70)
		
		
#Estatísticas		
def totalpart(agenda,medida,modalidade):
	
	cont = 0
	for a in agenda:
		cont += 1
	cont = str(cont)
	clear()
	gotoxyz(11,17, cont)
	gotoxyz(11,18," pessoas estao participando da competicao")
	time.sleep(3)
	clear()
	
# 3
def salvarAgenda(agenda,modalidade,chave):
	if modalidade == "corrida":
		bubbleSort(agenda,chave)
	else:
		bubbleSortReverse(agenda,chave)
	try:
		arquivo = open(modalidade + '.json', 'w')
		json.dump(agenda, arquivo, indent=1)			
		arquivo.close()
	except: 
		print("Erro ao salvar arquivos")
	

# 4 
def mostraagenda(agenda,medida,modalidade):
	if (str(medida) == "tempo"):
		for a in agenda:
			print("="*25, "\n")
			print("Nome :", a['nome'], '\n' "tempo em segundos:", a['tempo em segundos'], '\nPaís: ', a['pais'], '\n')
		
	if (str(medida) == "metros"):
		for a in agenda:
			print("="*25, "\n")
			print("Nome :", a['nome'], '\n' "Distancia em metros:", a['distancia em metros'], '\nPaís: ', a['pais'], '\n')
		
	if (str(medida) == "pontuacao"):
		for a in agenda:
			print("="*25, "\n")
			print("Nome :", a['nome'], '\n' "pontuacao:", a['pontuacao'], '\nPaís: ', a['pais'], '\n')

#5						
def deletar(agenda,medida,modalidade,chave):
	alvo = input("Digite o nome do participante a ser deletado:")
	for a in agenda:
		if a['nome'] == alvo:
			agenda.remove(a)
			if medida == 'tempo':
				salvarAgenda(agenda,'corrida',chave)
			elif medida == 'metros':
				salvarAgenda(agenda,'salto em distancia',chave)
			elif medida == 'pontuacao':
				salvarAgenda(agenda,'tiro esportivo',chave)
	

